package myapp.src.main;

import java.awt.Desktop;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        // Criação da janela principal
        JFrame frame = new JFrame("GUI de Ordenação");
        frame.setSize(600, 600); // Aumentado para acomodar a barra de progresso
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        // Adicionando o rótulo para seleção do tamanho do array
        JLabel labelTamanho = new JLabel("Escolha o tamanho do array:");
        labelTamanho.setBounds(160, 20, 360, 40);
        frame.add(labelTamanho);

        // Adicionando o ComboBox para seleção de tamanhos predefinidos
        String[] tamanhos = { "100", "1000", "10000", "100000", "1000000" };
        JComboBox<String> comboBoxTamanho = new JComboBox<>(tamanhos);
        comboBoxTamanho.setBounds(160, 60, 100, 30);
        frame.add(comboBoxTamanho);

        // Campo de texto para inserção de tamanho personalizado
        JTextField textFieldTamanhoPersonalizado = new JTextField();
        textFieldTamanhoPersonalizado.setBounds(265, 60, 100, 30);
        frame.add(textFieldTamanhoPersonalizado);

        // Botão para iniciar a ordenação
        JButton botaoOrdenar = new JButton("Ordenar");
        botaoOrdenar.setBounds(160, 100, 100, 30);
        frame.add(botaoOrdenar);

        // Área de texto para exibir os resultados
        JTextArea areaResultado = new JTextArea();
        areaResultado.setBounds(40, 180, 500, 300);
        areaResultado.setEditable(false);
        frame.add(areaResultado);

        // Botão para salvar os resultados em um arquivo CSV
        JButton botaoSalvar = new JButton("Salvar Resultado");
        botaoSalvar.setBounds(270, 100, 150, 30);
        frame.add(botaoSalvar);

        // Botão para abrir o arquivo CSV no Excel
        JButton botaoGrafico = new JButton("Abrir CSV no Excel");
        botaoGrafico.setBounds(200, 500, 150, 30);
        frame.add(botaoGrafico);

        // Adicionando a barra de progresso
        JProgressBar progressBar = new JProgressBar();
        progressBar.setBounds(40, 140, 500, 30);
        progressBar.setStringPainted(true); // Exibe o percentual concluído na barra
        frame.add(progressBar);

        // Adicionando ação ao botão de ordenação
        botaoOrdenar.addActionListener(e -> {
            // Obtendo o tamanho do array a ser ordenado
            String tamanhoStr = textFieldTamanhoPersonalizado.getText();
            int tamanho;

            if (tamanhoStr.isEmpty()) {
                tamanho = Integer.parseInt((String) comboBoxTamanho.getSelectedItem());
            } else {
                try {
                    tamanho = Integer.parseInt(tamanhoStr);
                    if (tamanho <= 0) {
                        areaResultado.setText("Tamanho inválido. Por favor, insira um número positivo.");
                        return;
                    }
                } catch (NumberFormatException ex) {
                    areaResultado.setText("Tamanho inválido. Por favor, insira um número válido.");
                    return;
                }
            }

            // Definindo os métodos e ordens de ordenação
            String[] metodos = { "InsertionSort", "BubbleSort", "SelectionSort" };
            String[] ordens = { "Crescente", "Decrescente", "Nenhum" };
            StringBuilder resultados = new StringBuilder();
            resultados.append("Tamanho ").append(tamanho).append(" : Execuções\n");

            // ExecutorService para executar tarefas de forma assíncrona
            ExecutorService executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
            progressBar.setIndeterminate(true); // Ativa o modo indeterminado enquanto ordena

            // SwingWorker para executar a ordenação em segundo plano e atualizar a GUI
            SwingWorker<Void, Integer> worker = new SwingWorker<>() {
                @Override
                protected Void doInBackground() throws Exception {
                    int totalTasks = metodos.length * ordens.length; // Calcula o total de tarefas
                    int completedTasks = 0; // Inicializa o contador de tarefas concluídas

                    for (String ordem : ordens) {
                        resultados.append("Ordem ").append(ordem).append("\n");

                        for (String metodo : metodos) {
                            long somaDuracao = 0;
                            int repeticoes = 10;

                            for (int i = 0; i < repeticoes; i++) {
                                int[] arr = Utils.gerarArrayAleatorio(tamanho, ordem);

                                Callable<Long> task = () -> {
                                    long tempoInicio = System.nanoTime();
                                    switch (metodo) {
                                        case "InsertionSort" -> InsertionSort.ordenar(arr);
                                        case "BubbleSort" -> BubbleSort.ordenar(arr);
                                        case "SelectionSort" -> SelectionSort.ordenar(arr);
                                    }
                                    long tempoFim = System.nanoTime();
                                    return (tempoFim - tempoInicio) / 1000000;
                                };

                                try {
                                    Future<Long> future = executor.submit(task);
                                    long duracao = future.get(30, TimeUnit.SECONDS);
                                    somaDuracao += duracao;
                                } catch (ExecutionException | InterruptedException
                                        | java.util.concurrent.TimeoutException ex) {
                                    somaDuracao += 30000; // Se houver exceção, considera a duração como 30000 ms (timeout).
                                }
                            }
                            long duracaoMedia = somaDuracao / repeticoes;
                            resultados.append(metodo).append(": ").append(duracaoMedia).append(" ms\n");

                            completedTasks++;
                            int progress = (int) ((completedTasks / (float) totalTasks) * 100);
                            publish(progress); // Publica o progresso para atualizar a barra de progresso
                        }
                    }
                    return null;
                }

                @Override
                protected void process(java.util.List<Integer> chunks) {
                    int progress = chunks.get(chunks.size() - 1);
                    progressBar.setValue(progress); // Define o valor da barra de progresso
                }

                @Override
                protected void done() {
                    try {
                        get();
                        areaResultado.setText(resultados.toString());
                    } catch (InterruptedException | ExecutionException ex) {
                        areaResultado.setText("Erro ao executar a ordenação: " + ex.getMessage());
                    } finally {
                        executor.shutdown();
                        progressBar.setIndeterminate(false);
                        progressBar.setValue(100);
                    }
                }
            };

            worker.execute();
        });

        // Adicionando ação ao botão de salvar
        botaoSalvar.addActionListener(e -> {
            try {
                try (FileWriter writer = new FileWriter("resultados.csv")) {
                    writer.write(areaResultado.getText().replace(" ", ",").replace("\n", System.lineSeparator()));
                }
                areaResultado.append("\nSalvo em resultados.csv");
            } catch (IOException ioException) {
                areaResultado.append("\nFalha ao salvar o arquivo");
            }
        });

        // Adicionando ação ao botão de abrir o CSV no Excel
        botaoGrafico.addActionListener(e -> {
            try {
                File csvFile = new File("resultados.csv");
                if (csvFile.exists() && Desktop.isDesktopSupported()) {
                    Desktop.getDesktop().open(csvFile);
                } else {
                    areaResultado.append(
                            "\nO arquivo resultados.csv não foi encontrado ou a funcionalidade de Desktop não é suportada.");
                }
            } catch (IOException ioException) {
                areaResultado.append("\nFalha ao abrir o arquivo CSV no Excel: " + ioException.getMessage());
            }
        });

        // Tornando a janela visível
        frame.setVisible(true);
    }
}

// Implementação do Bubble Sort
public class BubbleSort {
    public static void ordenar(int[] arr) {
        boolean swapped;
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            swapped = false;
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                    swapped = true;
                }
            }
            // Se nenhum elemento foi trocado, então o array já está ordenado
            if (!swapped) break;
        }
    }
}

// Implementação do Selection Sort
public class SelectionSort {
    public static void ordenar(int[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            // Encontra o menor elemento no array não ordenado
            int minIndex = i;
            for (int j = i + 1; j < n; j++) {
                if (arr[j] < arr[minIndex]) {
                    minIndex = j;
                }
            }
            // Troca o menor elemento com o primeiro elemento não ordenado
            int temp = arr[minIndex];
            arr[minIndex] = arr[i];
            arr[i] = temp;
        }
    }
}
